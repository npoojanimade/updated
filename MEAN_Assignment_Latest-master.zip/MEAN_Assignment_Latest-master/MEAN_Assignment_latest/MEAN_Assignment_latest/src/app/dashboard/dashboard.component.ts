import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { Response } from "@angular/http";

import { DashboardService } from "./../../app/services/app.dashboard.service";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  user:string;   
  role:string;
   token:string;
  forUser:boolean = false;

  accessUsers:string;
  operators:string;

  constructor(private router:Router, private serve:DashboardService) {

   }

  ngOnInit() {
  this.user = sessionStorage.getItem('user')
  this.role = sessionStorage.getItem('role')
   this.token = sessionStorage.getItem('token')
  
  if(this.role === 'AccessUser'){
    this.forUser = true;
    
        
    this.router.navigate(['dashboard/personinfo/', this.user])
  
}




  }


}
