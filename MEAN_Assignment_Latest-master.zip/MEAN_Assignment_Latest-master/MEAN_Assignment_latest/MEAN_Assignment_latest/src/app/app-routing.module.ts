import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AccessUserComponent } from './access-user/access-user.component';
import { RoleComponent } from './role/role.component';
import {UserComponent} from './user/user.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PersonComponent } from './person/person.component';
import { PersonalinfolistComponent } from './personlist/personalinfolist.component';
import { PersonalinfolisttempComponent } from './personalinfolisttemp/personalinfolisttemp.component';

const routes: Routes = [{
  path:'',
  component:LoginComponent
},
{
  path:'login',
  component:LoginComponent
},
{
  path:'dashboard',
  component:DashboardComponent,
  children :[{
              path:'role',
              component:RoleComponent
            },
            {
              path:'user',
              component:UserComponent
            }, 
            {
              path:'users',
              component:AccessUserComponent
            },
            {
              path:'person',
              component:PersonComponent
            },
            {
              path:'personalinfo/:userName',
              component:PersonalinfolistComponent,
              
           },
           {
               path:'personinfolist',
               component:PersonalinfolistComponent,
              
           },
           {
               path:'personalinfolisttemp',
               component:PersonalinfolisttempComponent,
             
           }

]
},
{
  path:'role',
  component:RoleComponent
},
{
  path:'user',
  component:UserComponent
}, 
{
  path:'users',
  component:AccessUserComponent
},  
{
  path:'person',
  component:PersonComponent
} , 
{
  path:'personalinfo/:userName',
  component:PersonalinfolistComponent,
  
},
{
   path:'personinfolist',
   component:PersonalinfolistComponent,
  
},
{
   path:'personalinfolisttemp',
   component:PersonalinfolisttempComponent,
 
}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
