import { Component, OnInit } from '@angular/core';
import {PersonCreateService} from './../services/app.addperson.services';
import {PersonInfo} from './../Model/app.person.model';
import {Response} from '@angular/http';
import { Router } from '@angular/router';


@Component({
  selector: 'app-person',
  templateUrl: './person.component.html',
  styleUrls: ['./person.component.css']
})
export class PersonComponent implements OnInit {

  person:PersonInfo;
  persons:Array<PersonInfo>;
  token:string;
  user:string;
   //frmPersonalInfo:FormGroup;
  role:number;

  constructor(private serve:PersonCreateService, private router:Router, private route :ActivatedRoute) {

    
    this.person = new PersonInfo("","","","","","",0,"","","","",0,0,0,"","","","");
    this.persons = new Array<PersonInfo>();

    this.token = sessionStorage.getItem('token');
    this.role = (sessionStorage.getItem('role'));
    this.user="";

   

   }

  ngOnInit() {
    let person1 = this.route.params.subscribe(params =>{
      this.user = params['userName']     
      
    })
            
      this.serve.getPersonalInfoByUserName(this.user, this.token).subscribe(
      (resp:Response) => {
        this.persons = resp.json().data
        
        
      },
      error => {
        console.log(`Error occured ${error}`);
        
      }
           
    ) 
  }

  save():void{
    
    //this.person = this.frmPersonalInfo.getRawValue()
                

    if(this.role ===1){
    this.serve.postData(this.person, this.token).subscribe(
     (resp:Response) => {
      alert(resp.json().message)
     },
     error => {
       console.log(`Error occured ${error}`);
     } 
    )
    }
    else{
      this.serve.postDataTemp(this.person, this.token).subscribe(
        (resp:Response) => {
         alert(resp.json().message)
        },
        error => {
          console.log(`Error occured ${error}`);
        } 
       ) 
    }

    


  }


}
