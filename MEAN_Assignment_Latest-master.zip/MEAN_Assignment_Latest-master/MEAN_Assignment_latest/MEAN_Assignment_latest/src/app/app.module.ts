import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpModule} from '@angular/http';

import { LoginComponent } from './login/login.component';
import { OperatorComponent } from './operator/operator.component';
import { AdminComponent } from './admin/admin.component';
import { AccessUserComponent } from './access-user/access-user.component';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';

import {UserService} from './services/app.user.services';
import {UserRoleService} from './services/app.userrole.services';
import { RoleComponent } from './role/role.component';
import { UserComponent } from './user/user.component';
import { UserCreateService } from './services/app.usercreate.services';
import { GetUserService } from './services/app.getusers.services';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PersonComponent } from './person/person.component';
import { PersonCreateService } from './services/app.addperson.services';

import { DashboardService } from './services/app.dashboard.service';



@NgModule({
  declarations: [
    AppComponent,

    LoginComponent,
    OperatorComponent,
    AdminComponent,
    AccessUserComponent,
    RoleComponent,
    UserComponent,
    DashboardComponent,
    PersonComponent,PersonalinfolistComponent,
    PersonalinfolisttempComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpModule
  ],
  providers: [UserService, UserRoleService,UserCreateService,GetUserService,PersonCreateService,DashboardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
