import { Injectable } from '@angular/core';
// import { Router } from '@angular/router';
import {Http, Response, Headers, RequestOptions} from '@angular/http';
import { Observable} from 'rxjs';
import { UserRole } from '../model/app.role.model';

@Injectable()
export class UserRoleService {
   url: string;
constructor(private http: Http) {
   this.url = 'http://localhost:3000';

}

CreateRole(role: UserRole): Observable<Response> {
   let resp: Observable<Response>;
   const header: Headers = new Headers({'Content-Type': 'application/json'});
   const options: RequestOptions = new RequestOptions();
   options.headers = header;
   resp = this.http.post(`${this.url}/api/userrolecrt`,
   JSON.stringify(role),
   options);
   console.log(JSON.stringify(resp));
   return resp;
}
}
