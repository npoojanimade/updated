export class UsersCreate {
  constructor(
      public Usr_Id: any,
      public UserType: string,
      public UserName: string,
      public PassWord: string
  ) {}
}
