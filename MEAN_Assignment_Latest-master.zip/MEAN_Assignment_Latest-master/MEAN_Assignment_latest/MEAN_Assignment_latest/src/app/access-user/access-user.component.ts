import { Component, OnInit } from '@angular/core';
import {UsersCreate} from './../Model/app.users.model';
import {GetUserService} from './../services/app.getusers.services';
import {Response} from '@angular/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-access-user',
  templateUrl: './access-user.component.html',
  styleUrls: ['./access-user.component.css']
})
export class AccessUserComponent implements OnInit {
  user:UsersCreate;
  users:Array<UsersCreate>;
  tableHeaders:Array<string>;

 uu: UsersCreate;
  // private roles: Array<UserRole>;
    constructor(private serve: GetUserService,private router:Router) {
        this.uu = new UsersCreate('', '', '', '');
    }

  ngOnInit() {
    for(let p in this.users)
    {
           this.tableHeaders.push(p);
    }
    
    this.serve.getusers().subscribe(
      (resp: Response) => {
          this.users= resp.json().data;
          console.log(resp.json().data);
          console.log(JSON.stringify(resp.json().data));
      },
      error => {
          console.log(`Error occured ${error}`);
   
      }
     );
}
 clear ():void{
     this.user=new UsersCreate("","","","");
 }

getselectdrow(p:UsersCreate):void{

//1. create a deep copy of the selected product 
//2. assign that copy to this.product
        this.user=Object.assign({},p);
}

createperson(): void {
  this.router.navigate(['./dashboard/person']);
}
  }

//}
