import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { Response } from "@angular/http";


import { PersonInfo } from "./../../app/Model/app.person.model";
import { PersonCreateService } from "./../../app/services/app.addperson.services";

@Component({
  selector: 'app-personalinfolist',
  templateUrl: './personalinfolist.component.html',
  styleUrls: ['./personalinfolist.component.css']
})
export class PersonalinfolistComponent implements OnInit {

  person:PersonInfo;
  persons:Array<PersonInfo>;
  token:string;

  constructor(private serve:PersonCreateService, private router:Router) {

    this.person = new PersonInfo("","","","","","",0,"","","","",0,0,0,"","","","");
    this.persons = new Array<PersonInfo>();

    this.token = sessionStorage.getItem('token');
   }

  ngOnInit() :void{

    this.serve.getPersonalInfo(this.token).subscribe(

      (resp:Response) => {
        this.persons = resp.json().data;
        console.log("resp ===", this.persons);
        
      },
      error => {
        console.log(`Error occured ${error}`);
        
      }
    )
    
  }

  navigateToUserList():void{
    this.router.navigate(['dashboard/access-user'])
  }

  navigateToPendingList():void{
    this.router.navigate(['dashboard/personalinfolisttemp'])
  }

}
