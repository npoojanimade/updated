import { Component, OnInit } from '@angular/core';
import {UserRole} from './../Model/app.role.model';
import {UserRoleService} from './../services/app.userrole.services';
import {Response} from '@angular/http';
import { Router } from '@angular/router';



@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css']
})
export class RoleComponent implements OnInit {
role: UserRole;
  // private roles: Array<UserRole>;
    constructor(private serve: UserRoleService) {
        this.role = new UserRole('', '', '', '');
    }
    save(): void {
      this.serve.CreateRole( this.role).subscribe(
       (resp: Response) => {
          //  this.roles.push(resp.json().data);
           console.log(resp.json().data);
       },
       error => {
           console.log(`Error occured ${error}`);

       }
      );
    }

    clear(): void {
      this.role = new UserRole('' , '', '' , '');
    }
  ngOnInit() {
  }

}
